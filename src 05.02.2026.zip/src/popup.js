// popup.js
(function() {
  'use strict';

  let timerInterval = null;

  function showStatus(message, duration = 2000) {
    const statusEl = document.getElementById('status');
    statusEl.textContent = message;
    statusEl.classList.add('show');
    setTimeout(() => {
      statusEl.classList.remove('show');
    }, duration);
  }

  // Format milliseconds to MM:SS
  function formatTime(ms) {
    const totalSeconds = Math.floor(ms / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  }

  // Update UI based on session state
  async function updateUI() {
    const result = await chrome.storage.local.get(['sessionActive', 'currentSession', 'currentTask']);

    if (result.sessionActive && result.currentSession) {
      // Show active session UI
      document.getElementById('session-setup').style.display = 'none';
      document.getElementById('session-active').style.display = 'block';

      // Update session info
      document.getElementById('session-user-id').textContent = result.currentSession.userId;
      document.getElementById('session-mode').textContent =
          result.currentSession.mode === 'trackpad' ? 'Trackpad' : 'AI Mouse';
      document.getElementById('session-interactions').textContent = result.currentSession.totalInteractions || 0;

      // Update current task info
      if (result.currentTask) {
        document.getElementById('current-task-info').style.display = 'block';
        document.getElementById('current-task-label').textContent = result.currentTask.taskDesc;
        document.getElementById('current-task-target').textContent = result.currentTask.targetText;
        document.getElementById('next-task-btn').style.display = 'none'; // Hide next task button during active task
      } else {
        // No active task - might be between tasks
        document.getElementById('current-task-info').style.display = 'none';
      }

      // Start timer
      startTimer(result.currentSession.sessionStartTs);
    } else {
      // Show setup UI
      document.getElementById('session-setup').style.display = 'block';
      document.getElementById('session-active').style.display = 'none';

      // Stop timer
      if (timerInterval) {
        clearInterval(timerInterval);
        timerInterval = null;
      }
    }
  }

  // Start countdown timer
  function startTimer(sessionStart) {
    const SESSION_DURATION = 15 * 60 * 1000; // 15 minutes

    // Clear existing timer
    if (timerInterval) {
      clearInterval(timerInterval);
    }

    timerInterval = setInterval(async () => {
      const elapsed = Date.now() - sessionStart;
      const remaining = Math.max(0, SESSION_DURATION - elapsed);

      document.getElementById('session-timer').textContent = formatTime(remaining);

      // Update interaction count and task info
      const result = await chrome.storage.local.get(['currentSession', 'currentTask']);
      if (result.currentSession) {
        document.getElementById('session-interactions').textContent = result.currentSession.totalInteractions || 0;

        // Update current task display
        if (result.currentTask) {
          document.getElementById('current-task-info').style.display = 'block';
          document.getElementById('current-task-label').textContent = result.currentTask.taskDesc;
          document.getElementById('current-task-target').textContent = result.currentTask.targetText;
        }
      }

      if (remaining === 0) {
        clearInterval(timerInterval);
        timerInterval = null;
        showStatus('Session ended - 15 minutes elapsed', 3000);
        setTimeout(updateUI, 1000);
      }
    }, 1000);
  }

  // Start session button
  document.getElementById('start-session-btn').addEventListener('click', async () => {
    const userId = document.getElementById('user-id-input').value.trim();
    const mode = document.getElementById('mode-select').value;

    if (!userId) {
      showStatus('Please enter a User ID', 2000);
      return;
    }

    try {
      // Send message to background script to start session
      const response = await chrome.runtime.sendMessage({
        action: 'startSession',
        userId: userId,
        mode: mode
      });

      if (response.success) {
        showStatus('Session started!', 2000);
        await updateUI();
      } else {
        showStatus('Error: ' + (response.error || 'Failed to start session'), 3000);
      }
    } catch (error) {
      console.error('Error starting session:', error);
      showStatus('Error starting session', 2000);
    }
  });

  // End session button
  document.getElementById('end-session-btn').addEventListener('click', async () => {
    try {
      const response = await chrome.runtime.sendMessage({
        action: 'endSession'
      });

      if (response.success) {
        showStatus('Session ended - Data exported!', 3000);
        await updateUI();
      } else {
        showStatus('Error: ' + (response.error || 'Failed to end session'), 3000);
      }
    } catch (error) {
      console.error('Error ending session:', error);
      showStatus('Error ending session', 2000);
    }
  });

  // Next task button (shown between tasks)
  document.getElementById('next-task-btn').addEventListener('click', async () => {
    try {
      const response = await chrome.runtime.sendMessage({
        action: 'continueNextTask'
      });

      if (response.success) {
        showStatus('Starting next task...', 2000);
        await updateUI();
      } else {
        showStatus('Error: ' + (response.error || 'Failed to start next task'), 3000);
      }
    } catch (error) {
      console.error('Error starting next task:', error);
      showStatus('Error starting next task', 2000);
    }
  });

  // Skip task button (inside task info box)
  document.getElementById('skip-task-btn').addEventListener('click', async () => {
    try {
      const response = await chrome.runtime.sendMessage({
        action: 'continueNextTask'
      });

      if (response.success) {
        showStatus('Skipping to next task...', 2000);
        await updateUI();
      } else {
        showStatus('Error: ' + (response.error || 'Failed to skip task'), 3000);
      }
    } catch (error) {
      console.error('Error skipping task:', error);
      showStatus('Error skipping task', 2000);
    }
  });

  // How to button - show modal
  const howtoBtn = document.getElementById('howto-btn');
  const howtoModal = document.getElementById('howto-modal');
  const modalCloseBtn = document.getElementById('modal-close-btn');

  howtoBtn.addEventListener('click', () => {
    howtoModal.classList.add('show');
  });

  modalCloseBtn.addEventListener('click', () => {
    howtoModal.classList.remove('show');
  });

  // Close modal when clicking outside
  howtoModal.addEventListener('click', (e) => {
    if (e.target === howtoModal) {
      howtoModal.classList.remove('show');
    }
  });

  // Cite button - show citation modal
  const citeBtn = document.getElementById('cite-btn');
  const citeModal = document.getElementById('cite-modal');
  const citeModalCloseBtn = document.getElementById('cite-modal-close-btn');

  citeBtn.addEventListener('click', () => {
    citeModal.classList.add('show');
  });

  citeModalCloseBtn.addEventListener('click', () => {
    citeModal.classList.remove('show');
  });

  // Close citation modal when clicking outside
  citeModal.addEventListener('click', (e) => {
    if (e.target === citeModal) {
      citeModal.classList.remove('show');
    }
  });

  // Initialize UI on load
  updateUI();

  // Listen for storage changes to update UI in real-time
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local') {
      updateUI();
    }
  });
})();