// background.js - Service worker for managing sessions

import { sessionManager } from './sessionManager.js';

// Initialize session manager on startup
chrome.runtime.onStartup.addListener(async () => {
    console.log('🚀 Extension startup - restoring session');
    await sessionManager.restoreSession();
});

// Initialize on extension installation
chrome.runtime.onInstalled.addListener(async () => {
    console.log('📦 Extension installed - restoring session');
    await sessionManager.restoreSession();
});

// Handle messages from popup and content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('📩 Background received message:', request.action, 'from tab:', sender.tab?.id);

    (async () => {
        try {
            if (request.action === 'startSession') {
                console.log('▶️ Starting session:', request.userId, request.mode);
                // Start a new session
                const sessionData = await sessionManager.startSession(request.userId, request.mode);
                console.log('✅ Session started successfully:', sessionData);
                sendResponse({ success: true, data: sessionData });

                // Start first task after a short delay
                setTimeout(async () => {
                    const task = await sessionManager.startTask(0);
                    console.log('📋 First task started:', task.taskLabel);
                }, 1000);
            }
            else if (request.action === 'startNextTask') {
                const taskIndex = request.taskIndex;
                const task = await sessionManager.startTask(taskIndex);
                console.log('📋 Task started:', task.taskLabel);
                sendResponse({ success: true, task });
            }
            else if (request.action === 'continueNextTask') {
                console.log('➡️ Continuing to next task');
                await sessionManager.continueToNextTask();
                sendResponse({ success: true });
            }
            else if (request.action === 'endSession') {
                console.log('⏹️ Ending session');
                // End the current session
                const finalData = await sessionManager.endSession();
                console.log('✅ Session ended, interactions:', finalData?.totalInteractions || 0);
                sendResponse({ success: true, data: finalData });
            }
            else if (request.action === 'getSessionInfo') {
                console.log('ℹ️ Getting session info');
                // Get current session information
                const info = sessionManager.getSessionInfo();
                console.log('📊 Session info:', info);
                sendResponse({ success: true, data: info });
            }
            else if (request.action === 'logInteraction') {
                console.log('📝 Logging interaction:', request.data);
                // Log an interaction during active session
                await sessionManager.logInteraction(request.data);
                console.log('✅ Interaction logged, total now:', sessionManager.sessionData?.totalInteractions);
                sendResponse({ success: true });
            }
            else {
                console.warn('⚠️ Unknown action:', request.action);
                sendResponse({ success: false, error: 'Unknown action' });
            }
        } catch (error) {
            console.error('❌ Background script error:', error);
            sendResponse({ success: false, error: error.message });
        }
    })();

    // Return true to indicate async response
    return true;
});

// Listen for tab updates to track user behavior
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete') {
        // Check if session is active
        const stored = await chrome.storage.local.get(['sessionActive']);
        if (stored.sessionActive) {
            console.log('🌐 Tab loaded during active session:', tab.url);
            // Tab loaded - could track navigation metrics here if needed
        }
    }
});

// Keep service worker alive with periodic checks
let keepAliveInterval = null;

function startKeepAlive() {
    if (keepAliveInterval) return;

    console.log('💚 Starting keep-alive');
    keepAliveInterval = setInterval(async () => {
        // Check session status periodically
        await sessionManager.restoreSession();
    }, 30000); // Every 30 seconds
}

function stopKeepAlive() {
    if (keepAliveInterval) {
        console.log('💔 Stopping keep-alive');
        clearInterval(keepAliveInterval);
        keepAliveInterval = null;
    }
}

// Start keep-alive on load
startKeepAlive();

// Monitor storage changes to detect session state
chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local' && changes.sessionActive) {
        console.log('🔄 Session state changed:', changes.sessionActive.newValue);
        if (changes.sessionActive.newValue) {
            startKeepAlive();
        } else {
            stopKeepAlive();
        }
    }
});