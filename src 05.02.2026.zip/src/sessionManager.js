// sessionManager.js - Handles user study sessions with data collection and export

class SessionManager {
    constructor() {
        this.sessionData = null;
        this.sessionActive = false;
        this.sessionTimer = null;
        this.currentTask = null;
        this.currentTaskIndex = 0;
        this.lastInteractionTime = null;
        this.SESSION_DURATION_MS = 15 * 60 * 1000; // 15 minutes
        this.waitingForTaskContinue = false;
    }

    // Predefined task list
    TASKS = [
        {
            taskId: "task_0001",
            taskType: "COMMAND",
            taskDesc: "Compose an email",
            targetText: "Compose",
            url: "https://mail.google.com"
        },
        {
            taskId: "task_0002",
            taskType: "SETTINGS",
            taskDesc: "Open settings menu",
            targetText: "Settings",
            url: "https://mail.google.com"
        },
        {
            taskId: "task_0003",
            taskType: "COMMAND",
            taskDesc: "Search your mail",
            targetText: "Search",
            url: "https://mail.google.com"
        }
        // Add more tasks as needed
    ]

    async startSession(userId, mode) {
        if (this.sessionActive) {
            throw new Error('Session already active');
        }

        const now = Date.now();
        const sessionDate = new Date(now).toISOString().split('T')[0]; // YYYY-MM-DD

        this.sessionData = {
            userId: userId,
            mode: mode, // 'trackpad' | 'ai'
            sessionStartTs: now,
            sessionEndTs: null,
            sessionDuration: 0,
            sessionDate: sessionDate,
            totalInteractions: 0,
            totalManualClicks: 0,
            totalAiMouseClicks: 0,
            tasks: []
        };

        this.sessionActive = true;
        this.currentTaskIndex = 0;
        this.lastInteractionTime = now;

        await chrome.storage.local.set({
            currentSession: this.sessionData,
            sessionActive: true
        });

        this.sessionTimer = setTimeout(() => {
            this.endSession();
        }, this.SESSION_DURATION_MS);

        this.broadcastSessionState();

        return this.sessionData;
    }

    async startTask(taskIndex = null) {
        if (!this.sessionActive) {
            throw new Error('No active session');
        }

        // Use provided index or current index
        if (taskIndex !== null) {
            this.currentTaskIndex = taskIndex;
        }

        const taskTemplate = this.TASKS[this.currentTaskIndex];
        if (!taskTemplate) {
            throw new Error('Invalid task index');
        }

        const now = Date.now();

        this.currentTask = {
            taskId: taskTemplate.taskId,
            taskType: taskTemplate.taskType,
            taskDesc: taskTemplate.taskDesc,
            targetText: taskTemplate.targetText,
            startTs: now,
            endTs: null,
            taskDuration: 0,
            success: false,
            errorCount: 0,
            interactions: []
        };

        this.lastInteractionTime = now;
        this.waitingForTaskContinue = false;

        // Save current task info
        await chrome.storage.local.set({
            currentSession: this.sessionData,
            currentTask: this.currentTask
        });

        // Broadcast task info to content script
        this.broadcastTaskInfo();

        return this.currentTask;
    }

    // Log an interaction during the session
    async logInteraction(interactionData) {
        if (!this.sessionActive) {
            return; // Don't log if no session is active
        }

        const now = Date.now();
        const timeSinceLastInteraction = this.lastInteractionTime
            ? now - this.lastInteractionTime
            : 0;

        // Determine if this is an error (not matching task target)
        let isError = false;
        if (this.currentTask) {
            const elementText = interactionData.elementText || '';
            const targetText = this.currentTask.targetText || '';

            // Simple matching - interaction is error if it doesn't match target
            isError = !elementText.toLowerCase().includes(targetText.toLowerCase());
        }

        const interaction = {
            timestamp: now,
            selectedIndex: interactionData.selectedIndex !== undefined ? interactionData.selectedIndex : -1,
            elementSelector: interactionData.elementSelector || '',
            elementText: interactionData.elementText || '',
            aiMouseClick: interactionData.aiMouseClick || false,
            manualClick: interactionData.manualClick || false,
            reward: interactionData.reward !== undefined ? interactionData.reward : null,
            cursorTraveledDistancePx: interactionData.cursorTraveledDistancePx || 0,
            timeSinceLastInteractionMs: timeSinceLastInteraction,
            isError: isError
        };

        // Add to current task if one is active
        if (this.currentTask) {
            this.currentTask.interactions.push(interaction);
            if (isError) {
                this.currentTask.errorCount++;
            }
        }

        // Update session totals
        this.sessionData.totalInteractions++;
        if (interaction.manualClick) {
            this.sessionData.totalManualClicks++;
        }
        if (interaction.aiMouseClick) {
            this.sessionData.totalAiMouseClicks++;
        }

        this.lastInteractionTime = now;

        await chrome.storage.local.set({
            currentSession: this.sessionData
        });

        // Check if task is complete (correct element clicked)
        if (this.currentTask && !isError && !this.waitingForTaskContinue) {
            await this.completeTask(true);
        }
    }

    async completeTask(success = true) {
        if (!this.currentTask) {
            return;
        }

        const now = Date.now();
        this.currentTask.endTs = now;
        this.currentTask.taskDuration = now - this.currentTask.startTs; // Keep in milliseconds
        this.currentTask.success = success;

        // Add task to session
        this.sessionData.tasks.push(this.currentTask);

        await chrome.storage.local.set({
            currentSession: this.sessionData,
            currentTask: null
        });

        // Move to next task
        this.currentTaskIndex++;
        const nextTask = this.TASKS[this.currentTaskIndex] || null;

        // Set waiting flag
        this.waitingForTaskContinue = true;

        // Notify content script that task is complete
        this.broadcastTaskComplete(nextTask);

        // Clear current task
        this.currentTask = null;

        return this.sessionData.tasks[this.sessionData.tasks.length - 1];
    }

    async continueToNextTask() {
        this.waitingForTaskContinue = false;

        // Complete current task as unsuccessful if it's still active
        if (this.currentTask) {
            await this.completeTask(false);
        }

        if (this.currentTaskIndex < this.TASKS.length) {
            // Start next task (currentTaskIndex was already incremented in completeTask)
            await this.startTask(this.currentTaskIndex);
        } else {
            // No more tasks, end session
            await this.endSession();
        }
    }

    // End the session and export data
    async endSession() {
        if (!this.sessionActive) {
            return null;
        }

        // Complete current task if active
        if (this.currentTask && !this.waitingForTaskContinue) {
            await this.completeTask(false); // Mark as unsuccessful
        }

        if (this.sessionTimer) {
            clearTimeout(this.sessionTimer);
            this.sessionTimer = null;
        }

        const now = Date.now();
        this.sessionData.sessionEndTs = now;
        this.sessionData.sessionDuration = now - this.sessionData.sessionStartTs; // Keep in milliseconds

        this.sessionActive = false;

        await chrome.storage.local.set({
            currentSession: null,
            currentTask: null,
            sessionActive: false
        });

        const jsonData = this.exportToJSON();
        this.downloadJSON(jsonData);

        this.broadcastSessionState();

        const finalData = { ...this.sessionData };
        this.sessionData = null;
        this.currentTaskIndex = 0;

        return finalData;
    }

    // Export session data as JSON string matching exact schema
    exportToJSON() {
        if (!this.sessionData) {
            return null;
        }

        // Build exact schema structure
        const cleanData = {
            userId: this.sessionData.userId,
            mode: this.sessionData.mode,
            sessionStartTs: this.sessionData.sessionStartTs,
            sessionEndTs: this.sessionData.sessionEndTs,
            sessionDuration: this.sessionData.sessionDuration,
            sessionDate: this.sessionData.sessionDate,
            totalInteractions: this.sessionData.totalInteractions,
            totalManualClicks: this.sessionData.totalManualClicks,
            totalAiMouseClicks: this.sessionData.totalAiMouseClicks,
            tasks: this.sessionData.tasks.map(task => ({
                taskId: task.taskId,
                taskType: task.taskType,
                taskDesc: task.taskDesc,
                targetText: task.targetText,
                startTs: task.startTs,
                endTs: task.endTs,
                taskDuration: task.taskDuration,
                success: task.success,
                errorCount: task.errorCount,
                interactions: task.interactions.map(interaction => ({
                    timestamp: interaction.timestamp,
                    selectedIndex: interaction.selectedIndex,
                    elementSelector: interaction.elementSelector,
                    elementText: interaction.elementText,
                    aiMouseClick: interaction.aiMouseClick,
                    manualClick: interaction.manualClick,
                    reward: interaction.reward,
                    cursorTraveledDistancePx: interaction.cursorTraveledDistancePx,
                    timeSinceLastInteractionMs: interaction.timeSinceLastInteractionMs,
                    isError: interaction.isError
                }))
            }))
        };

        return JSON.stringify(cleanData, null, 2);
    }

    // Download JSON file
    downloadJSON(jsonString) {
        if (!jsonString) {
            return;
        }

        const date = new Date();
        const dateStr = date.toISOString().replace(/[:.]/g, '-').split('T')[0];
        const timeStr = date.toTimeString().split(' ')[0].replace(/:/g, '-');
        const filename = `${this.sessionData.userId}_${this.sessionData.mode}_${dateStr}_${timeStr}.json`;

        const dataUrl = 'data:application/json;base64,' + btoa(unescape(encodeURIComponent(jsonString)));

        chrome.downloads.download({
            url: dataUrl,
            filename: filename,
            saveAs: true
        }, (downloadId) => {
            if (chrome.runtime.lastError) {
                console.error('Download error:', chrome.runtime.lastError);
            } else {
                console.log('Session data downloaded:', downloadId);
            }
        });
    }

    // Get current session info
    getSessionInfo() {
        if (!this.sessionActive) {
            return null;
        }

        const elapsed = Date.now() - this.sessionData.sessionStartTs;
        const remaining = Math.max(0, this.SESSION_DURATION_MS - elapsed);

        return {
            active: this.sessionActive,
            userId: this.sessionData.userId,
            mode: this.sessionData.mode,
            elapsed: elapsed,
            remaining: remaining,
            totalInteractions: this.sessionData.totalInteractions,
            currentTask: this.currentTask ? {
                taskDesc: this.currentTask.taskDesc,
                targetText: this.currentTask.targetText,
                taskNumber: this.currentTaskIndex + 1,
                totalTasks: this.TASKS.length
            } : null
        };
    }

    // Restore session from storage (in case of reload)
    async restoreSession() {
        const stored = await chrome.storage.local.get(['currentSession', 'sessionActive', 'currentTask']);

        if (stored.sessionActive && stored.currentSession) {
            this.sessionData = stored.currentSession;
            this.sessionActive = true;

            if (stored.currentTask) {
                this.currentTask = stored.currentTask;
            }

            const elapsed = Date.now() - this.sessionData.sessionStartTs;
            if (elapsed >= this.SESSION_DURATION_MS) {
                await this.endSession();
            } else {
                const remaining = this.SESSION_DURATION_MS - elapsed;
                this.sessionTimer = setTimeout(() => {
                    this.endSession();
                }, remaining);
            }
        }
    }

    broadcastSessionState() {
        chrome.tabs.query({}, (tabs) => {
            tabs.forEach(tab => {
                chrome.tabs.sendMessage(tab.id, {
                    action: 'sessionStateChanged',
                    sessionActive: this.sessionActive,
                    mode: this.sessionActive ? this.sessionData.mode : null
                }).catch(() => {});
            });
        });
    }

    broadcastTaskInfo() {
        if (!this.currentTask) return;

        chrome.tabs.query({}, (tabs) => {
            tabs.forEach(tab => {
                chrome.tabs.sendMessage(tab.id, {
                    action: 'taskStarted',
                    task: {
                        taskDesc: this.currentTask.taskDesc,
                        targetText: this.currentTask.targetText,
                        taskNumber: this.currentTaskIndex + 1,
                        totalTasks: this.TASKS.length
                    }
                }).catch(() => {});
            });
        });
    }

    broadcastTaskComplete(nextTask) {
        chrome.tabs.query({}, (tabs) => {
            tabs.forEach(tab => {
                chrome.tabs.sendMessage(tab.id, {
                    action: 'taskComplete',
                    nextTask: nextTask ? {
                        taskDesc: nextTask.taskDesc,
                        targetText: nextTask.targetText
                    } : null
                }).catch(() => {});
            });
        });
    }
}

// Export singleton instance
export const sessionManager = new SessionManager();