// heuristicRanker.js - Heuristic-based button ranking (no ML)

/**
 * Score candidates using heuristic rules based on:
 * - Distance from mouse cursor
 * - Visual prominence (size, position)
 * - Element type and role
 * - Text content relevance
 * - Focus history
 */

export function scoreAndRankCandidates(candidates, navState, maxResults = 15) {
    const mouseX = navState.mouse?.x || window.innerWidth / 2;
    const mouseY = navState.mouse?.y || window.innerHeight / 2;
    const focusHistory = navState.focusHistory || [];

    // Score each candidate
    const scored = candidates.map(candidate => {
        const element = candidate.element;
        const features = candidate.features;

        let score = 0;

        // 1. Distance from cursor (closer = higher score)
        const rect = element.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        const distance = Math.sqrt(
            Math.pow(centerX - mouseX, 2) +
            Math.pow(centerY - mouseY, 2)
        );

        // Normalize distance score (0-40 points)
        // Closer elements get higher scores
        const maxDistance = Math.sqrt(
            Math.pow(window.innerWidth, 2) +
            Math.pow(window.innerHeight, 2)
        );
        const distanceScore = 40 * (1 - Math.min(distance / maxDistance, 1));
        score += distanceScore;

        // 2. Viewport position (center-weighted, 0-20 points)
        const viewportCenterX = window.innerWidth / 2;
        const viewportCenterY = window.innerHeight / 2;
        const centerDistance = Math.sqrt(
            Math.pow(centerX - viewportCenterX, 2) +
            Math.pow(centerY - viewportCenterY, 2)
        );
        const viewportScore = 20 * (1 - Math.min(centerDistance / maxDistance, 1));
        score += viewportScore;

        // 3. Element size (larger = more prominent, 0-15 points)
        const area = rect.width * rect.height;
        const maxArea = window.innerWidth * window.innerHeight;
        const sizeScore = 15 * Math.min(area / (maxArea * 0.1), 1);
        score += sizeScore;

        // 4. Element type/role bonus (0-15 points)
        const tagName = element.tagName.toLowerCase();
        const role = element.getAttribute('role') || '';

        if (tagName === 'button' || role === 'button') {
            score += 15;
        } else if (tagName === 'a') {
            score += 12;
        } else if (tagName === 'input' && element.type === 'submit') {
            score += 14;
        } else if (role === 'link') {
            score += 10;
        }

        // 5. Text content quality (0-10 points)
        const text = features.text || '';
        if (text.length > 0) {
            // Prefer buttons with meaningful text (not too short, not too long)
            if (text.length >= 3 && text.length <= 20) {
                score += 10;
            } else if (text.length > 20 && text.length <= 50) {
                score += 5;
            } else if (text.length > 0) {
                score += 2;
            }
        }

        // Common action words get bonus
        const actionWords = ['submit', 'send', 'save', 'search', 'login', 'sign', 'continue', 'next', 'confirm', 'ok', 'yes', 'create', 'add', 'compose'];
        const lowerText = text.toLowerCase();
        if (actionWords.some(word => lowerText.includes(word))) {
            score += 8;
        }

        // 6. Visibility and positioning (0-10 points)
        const isVisible = features.isVisible !== false;
        const zIndex = parseInt(window.getComputedStyle(element).zIndex) || 0;

        if (isVisible) {
            score += 5;
        }

        if (zIndex > 0) {
            score += Math.min(zIndex / 100, 5); // Higher z-index = more prominent
        }

        // 7. Focus history bonus (0-10 points)
        // If user recently interacted with similar elements
        const recentlyFocused = focusHistory.slice(-5);
        for (let i = 0; i < recentlyFocused.length; i++) {
            const historyEl = recentlyFocused[i];
            if (historyEl && historyEl.tagName === element.tagName) {
                score += 2;
            }
            if (historyEl && historyEl.className === element.className) {
                score += 3;
            }
        }

        // 8. Vertical position preference (top of page often has important actions)
        const scrollY = window.scrollY || window.pageYOffset;
        const absoluteY = rect.top + scrollY;
        const pageHeight = document.documentElement.scrollHeight;

        // Slight preference for elements near the top
        if (absoluteY < pageHeight * 0.3) {
            score += 5;
        }

        return {
            ...candidate,
            heuristicScore: score
        };
    });

    // Sort by score (highest first)
    scored.sort((a, b) => b.heuristicScore - a.heuristicScore);

    // Return top N results
    return scored.slice(0, maxResults);
}

/**
 * Simple wrapper that matches the ML interface
 */
export function rankCandidatesHeuristic(candidates, navState, maxResults = 15) {
    return scoreAndRankCandidates(candidates, navState, maxResults);
}