'use strict';

/* ========= STATE ========= */

export const navState = {
    focusedElement: null,
    focusHistory: [],
    lastAction: null,
    mouse: { x: 0, y: 0 },
    maxHistory: 5
};

/* ========= FEATURE EXTRACTION ========= */

export function extractCandidates() {
    const candidates = [];
    const seen = new Set();
    const buttonSelectors = ['button', '[role="button"]', 'a[role="button"]', '[class*="T-I"]', '[class*="button"]', '[id*="button"]'];

    for (const selector of buttonSelectors) {
        const elements = Array.from(document.querySelectorAll(selector)).slice(0, 200);
        for (const el of elements) {
            if (seen.has(el) || !isVisible(el) || !isProminent(el)) continue;
            seen.add(el);
            //const rect = el.getBoundingClientRect();
            candidates.push({
                element: el,
                features: generateElementFeatures(el)
            });
        }
    }
    return candidates;
}

function generateElementFeatures(el) {
    const rect = el.getBoundingClientRect();
    return {
        tag: el.tagName.toLowerCase(),
        role: el.getAttribute('role') || '',
        text: getButtonText(el),
        rect: { x: rect.x, y: rect.y, w: rect.width, h: rect.height },
        className: getClassNameString(el).toLowerCase(),
        id: (el.id || '').toLowerCase()
    };
}

export function updateFocusHistory(element) {
    if (!element) return;

    navState.focusedElement = element;
    navState.focusHistory.push({
        element: element,  // ✅ ADD THIS LINE
        timestamp: Date.now(),
        features: generateElementFeatures(element)
    });

    if (navState.focusHistory.length > navState.maxHistory) {
        navState.focusHistory.shift();
    }
}

/* ========= HELPERS ========= */

function isVisible(el) {
    const rect = el.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return false;
    if (rect.bottom < 0 || rect.top > innerHeight) return false;

    const style = getComputedStyle(el);
    return style.display !== 'none' &&
        style.visibility !== 'hidden' &&
        parseFloat(style.opacity) > 0;
}

function isProminent(el) {
    const r = el.getBoundingClientRect();
    return r.width >= 20 && r.height >= 20;
}

function getClassNameString(el) {
    if (!el.className) return '';
    return typeof el.className === 'string'
        ? el.className
        : el.className.toString();
}

function getButtonText(el) {
    return el.getAttribute('aria-label') ||
        el.getAttribute('data-tooltip') ||
        el.title ||
        el.textContent?.trim().slice(0, 100) ||
        el.tagName.toLowerCase();
}