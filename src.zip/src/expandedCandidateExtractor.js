// contextAwareCandidateExtractor.js
// Context-aware extractor that adapts to Gmail regions

/**
 * Extract candidates with region context
 * @param {Object|null} region - The region object from regionManager, or null for global extraction
 * @returns {Array} Array of candidate objects
 */
export function extractCandidates(region = null) {
    if (!region) {
        return extractAllClickableCandidates();
    }

    // Context-aware extraction based on region
    switch (region.id) {
        case 'header':
            return extractHeaderCandidates(region);
        case 'top-navigation':
            return extractTopNavigationCandidates(region);
        case 'mail-navigation':
            return extractMailNavigationCandidates(region);
        case 'main':
            return extractMainCandidates(region);
        case 'left-panel':
            return extractLeftPanelCandidates(region);
        case 'right-panel':
            return extractRightPanelCandidates(region);
        default:
            return extractGenericCandidates(region);
    }
}

/**
 * Extract candidates from header region
 * Focus: Main menu, Search, Status, Settings, Google apps
 */
function extractHeaderCandidates(region) {
    const candidates = [];
    const seen = new Set();
    const container = region.element;

    const push = (el, reason = '') => {
        if (!el || seen.has(el)) return;
        if (!isElementVisible(el)) return;
        if (shouldIgnoreElement(el)) return;

        const r = el.getBoundingClientRect();
        if (r.width < 6 || r.height < 6) return;

        seen.add(el);
        candidates.push({
            element: el,
            features: extractFeatures(el, reason),
        });
    };

    // Priority header controls with specific aria-labels
    const headerTargets = [
        { selector: '[aria-label="Main menu"][role="button"]', reason: 'header:main-menu' },
        { selector: '[aria-label="Search mail"]', reason: 'header:search' },
        { selector: 'form[aria-label="Search mail"]', reason: 'header:search-form' },
        { selector: '[aria-label^="Status:"][role="button"]', reason: 'header:status' },
        { selector: '[aria-label="Settings"][role="button"]', reason: 'header:settings' },
        { selector: '[aria-label="Google apps"][role="button"]', reason: 'header:google-apps' },
        { selector: '[aria-label="Support"][role="button"]', reason: 'header:support' },
    ];

    headerTargets.forEach(({ selector, reason }) => {
        const elements = queryAllIn(container, selector);
        elements.forEach(el => push(el, reason));
    });

    // Search input field
    queryAllIn(container, 'input[type="text"][aria-label*="Search"]').forEach(el => {
        push(el, 'header:search-input');
    });

    // Profile/account button (often has aria-label with email or "Google Account")
    queryAllIn(container, '[aria-label*="Google Account"], [aria-label*="account" i]').forEach(el => {
        if (el.getAttribute('role') === 'button' || el.tagName.toLowerCase() === 'a') {
            push(el, 'header:account');
        }
    });

    console.log(`📍 Header: ${candidates.length} candidates`);
    return candidates;
}

/**
 * Extract candidates from top navigation region (div.aeH)
 * Focus: All buttons (Gmail, Chat, Spaces, Meet)
 */
function extractTopNavigationCandidates(region) {
    const candidates = [];
    const seen = new Set();
    const container = region.element;

    const push = (el, reason = '') => {
        if (!el || seen.has(el)) return;
        if (!isElementVisible(el)) return;
        if (shouldIgnoreElement(el)) return;

        const r = el.getBoundingClientRect();
        if (r.width < 6 || r.height < 6) return;

        seen.add(el);
        candidates.push({
            element: el,
            features: extractFeatures(el, reason),
        });
    };

    // Extract all buttons in the top navigation
    queryAllIn(container, 'button, [role="button"]').forEach(el => {
        push(el, 'top-nav:button');
    });

    // Also include any links that might be there
    queryAllIn(container, 'a[href], [role="link"]').forEach(el => {
        push(el, 'top-nav:link');
    });

    // Include tabs if present
    queryAllIn(container, '[role="tab"]').forEach(el => {
        push(el, 'top-nav:tab');
    });

    console.log(`📍 Top Navigation: ${candidates.length} candidates`);
    return candidates;
}

/**
 * Extract candidates from mail navigation region
 * Focus: Compose, Inbox, Starred, Sent, Drafts, More/Less toggles
 */
function extractMailNavigationCandidates(region) {
    const candidates = [];
    const seen = new Set();
    const container = region.element;

    const push = (el, reason = '') => {
        if (!el || seen.has(el)) return;
        if (!isElementVisible(el)) return;
        if (shouldIgnoreElement(el)) return;

        const r = el.getBoundingClientRect();
        if (r.width < 6 || r.height < 6) return;

        seen.add(el);
        candidates.push({
            element: el,
            features: extractFeatures(el, reason),
        });
    };

    // Compose button - highest priority
    queryAllIn(container, '[role="button"]').forEach(el => {
        const text = (el.textContent || '').trim();
        const ariaLabel = (el.getAttribute('aria-label') || '').trim();
        if (text === 'Compose' || ariaLabel === 'Compose') {
            push(el, 'nav:compose');
        }
    });

    // Navigation links (Inbox, Starred, Sent, etc.)
    const navLabels = [
        'Inbox',
        'Starred',
        'Snoozed',
        'Sent',
        'Drafts',
        'Spam',
        'Trash',
        'Categories',
        'More',
        'Less',
        'Important',
        'Chats',
        'Scheduled',
        'All Mail',
    ];

    // Try links and buttons with these labels
    queryAllIn(container, 'a, [role="link"], [role="button"], div[tabindex]').forEach(el => {
        const ariaLabel = (el.getAttribute('aria-label') || '').trim();
        const text = (el.textContent || '').trim();
        const dataTooltip = (el.getAttribute('data-tooltip') || '').trim();

        const matchedLabel = navLabels.find(label => {
            return ariaLabel === label || text === label || dataTooltip === label;
        });

        if (matchedLabel) {
            push(el, `nav:${matchedLabel.toLowerCase()}`);
        }
    });

    // More/Less toggles (have aria-expanded)
    queryAllIn(container, '[role="button"][aria-expanded]').forEach(el => {
        const text = (el.textContent || '').trim();
        if (text === 'More' || text === 'Less') {
            push(el, 'nav:toggle');
        }
    });

    // Labels section (often expandable)
    queryAllIn(container, '[data-tooltip*="label" i], [aria-label*="label" i]').forEach(el => {
        push(el, 'nav:label');
    });

    // Category links
    queryAllIn(container, '[href*="category/"]').forEach(el => {
        push(el, 'nav:category');
    });

    console.log(`📍 Mail Navigation: ${candidates.length} candidates`);
    return candidates;
}

/**
 * Extract candidates from main content area
 * Focus: Email rows (tr.zA), checkboxes, action buttons
 */
function extractMainCandidates(region) {
    const candidates = [];
    const seen = new Set();
    const container = region.element;

    const push = (el, reason = '') => {
        if (!el || seen.has(el)) return;
        if (!isElementVisible(el)) return;
        if (shouldIgnoreElement(el)) return;

        const r = el.getBoundingClientRect();
        if (r.width < 6 || r.height < 6) return;

        seen.add(el);
        candidates.push({
            element: el,
            features: extractFeatures(el, reason),
        });
    };

    // Toolbar actions (above email list)
    queryAllIn(container, '[role="toolbar"] [role="button"], [role="toolbar"] button').forEach(el => {
        const ariaLabel = (el.getAttribute('aria-label') || '').trim();
        if (ariaLabel) {
            push(el, 'main:toolbar-action');
        }
    });

    // Select all checkbox
    queryAllIn(container, '[role="checkbox"][aria-label*="Select" i]').forEach(el => {
        push(el, 'main:select-all');
    });

    // Email rows - PRIMARY TARGETS
    queryAllIn(container, 'tr.zA, tr[role="row"]').forEach(el => {
        // Verify it's actually an email row
        if (el.querySelector('[role="checkbox"]') ||
            el.querySelector('[role="link"]') ||
            (el.getAttribute('aria-label') || '').includes('Conversation')) {
            push(el, 'main:email-row');
        }
    });

    // Pagination controls
    queryAllIn(container, '[aria-label*="Older" i], [aria-label*="Newer" i]').forEach(el => {
        push(el, 'main:pagination');
    });

    // Page size selector
    queryAllIn(container, '[aria-label*="messages per page" i]').forEach(el => {
        push(el, 'main:page-size');
    });

    console.log(`📍 Main: ${candidates.length} candidates`);
    return candidates;
}

/**
 * Extract candidates from left panel (full navigation)
 */
function extractLeftPanelCandidates(region) {
    const candidates = [];
    const seen = new Set();
    const container = region.element;

    const push = (el, reason = '') => {
        if (!el || seen.has(el)) return;
        if (!isElementVisible(el)) return;
        if (shouldIgnoreElement(el)) return;

        const r = el.getBoundingClientRect();
        if (r.width < 6 || r.height < 6) return;

        seen.add(el);
        candidates.push({
            element: el,
            features: extractFeatures(el, reason),
        });
    };

    // All labeled links and buttons
    queryAllIn(container, 'a[aria-label], [role="link"][aria-label], [role="button"][aria-label]').forEach(el => {
        push(el, 'left-panel:labeled');
    });

    // Tooltipped elements
    queryAllIn(container, '[data-tooltip]').forEach(el => {
        push(el, 'left-panel:tooltip');
    });

    console.log(`📍 Left Panel: ${candidates.length} candidates`);
    return candidates;
}

/**
 * Extract candidates from right panel (Calendar, Keep, Tasks, Contacts)
 */
function extractRightPanelCandidates(region) {
    const candidates = [];
    const seen = new Set();
    const container = region.element;

    const push = (el, reason = '') => {
        if (!el || seen.has(el)) return;
        if (!isElementVisible(el)) return;
        if (shouldIgnoreElement(el)) return;

        const r = el.getBoundingClientRect();
        if (r.width < 6 || r.height < 6) return;

        seen.add(el);
        candidates.push({
            element: el,
            features: extractFeatures(el, reason),
        });
    };

    // Side panel tabs
    queryAllIn(container, '[role="tab"], [role="button"][aria-label]').forEach(el => {
        push(el, 'right-panel:tab');
    });

    // Interactive elements in side panel
    queryAllIn(container, 'button, a[href], [role="button"], [role="link"]').forEach(el => {
        if (el.getAttribute('aria-label') || el.getAttribute('data-tooltip')) {
            push(el, 'right-panel:action');
        }
    });

    console.log(`📍 Right Panel: ${candidates.length} candidates`);
    return candidates;
}

/**
 * Generic extraction for unknown regions
 */
function extractGenericCandidates(region) {
    const candidates = [];
    const seen = new Set();
    const container = region.element;

    const push = (el, reason = '') => {
        if (!el || seen.has(el)) return;
        if (!isElementVisible(el)) return;
        if (shouldIgnoreElement(el)) return;

        const r = el.getBoundingClientRect();
        if (r.width < 6 || r.height < 6) return;

        seen.add(el);
        candidates.push({
            element: el,
            features: extractFeatures(el, reason),
        });
    };

    const standardSelectors = [
        'button',
        'a[href]',
        'input',
        'select',
        'textarea',
        '[role="button"]',
        '[role="link"]',
        '[role="menuitem"]',
        '[role="tab"]',
        '[role="checkbox"]',
    ];

    queryAllIn(container, standardSelectors.join(',')).forEach(el => {
        if (isGoodLabeledTarget(el)) {
            push(el, 'generic');
        }
    });

    console.log(`📍 Generic (${region.id}): ${candidates.length} candidates`);
    return candidates;
}

/**
 * Fallback: extract all clickable candidates globally
 */
export function extractAllClickableCandidates() {
    const candidates = [];
    const seen = new Set();

    const push = (el, reason = '') => {
        if (!el || seen.has(el)) return;
        if (!isElementVisible(el)) return;
        if (shouldIgnoreElement(el)) return;

        const r = el.getBoundingClientRect();
        if (r.width < 6 || r.height < 6) return;

        seen.add(el);
        candidates.push({
            element: el,
            features: extractFeatures(el, reason),
        });
    };

    // Standard interactive elements
    const selectors = [
        'button',
        'a[href]',
        'input',
        'select',
        'textarea',
        '[role="button"]',
        '[role="link"]',
        '[role="checkbox"]',
        '[role="tab"]',
        'tr.zA',
    ];

    queryAll(selectors.join(',')).forEach(el => {
        if (isGoodLabeledTarget(el)) {
            push(el, 'global');
        }
    });

    console.log(`🌍 Global extraction: ${candidates.length} candidates`);
    return candidates;
}

/* -------------------------
 * Helper Functions
 * ------------------------- */

function queryAll(selector) {
    try {
        return Array.from(document.querySelectorAll(selector));
    } catch {
        return [];
    }
}

function queryAllIn(container, selector) {
    try {
        return Array.from(container.querySelectorAll(selector));
    } catch {
        return [];
    }
}

function isElementVisible(element) {
    const rect = element.getBoundingClientRect();

    if (rect.width <= 0 || rect.height <= 0) return false;

    const inViewport =
        rect.bottom >= -80 &&
        rect.right >= -80 &&
        rect.top <= window.innerHeight + 80 &&
        rect.left <= window.innerWidth + 80;

    if (!inViewport) return false;

    const style = window.getComputedStyle(element);
    if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;

    return true;
}

function shouldIgnoreElement(element) {
    const ignoreIds = [
        'smarttab-popup',
        'smarttab-lasso',
        'smarttab-chord',
        'task-notification',
        'tabtabgo-region-overlay',
        'tabtabgo-region-popup',
    ];

    if (ignoreIds.includes(element.id)) return true;

    for (const id of ignoreIds) {
        if (element.closest(`#${id}`)) return true;
    }

    return false;
}

function isGoodLabeledTarget(el) {
    const tag = el.tagName ? el.tagName.toLowerCase() : '';
    const role = (el.getAttribute('role') || '').toLowerCase();

    const ariaLabel = (el.getAttribute('aria-label') || '').trim();
    const tooltip = (el.getAttribute('data-tooltip') || '').trim();
    const title = (el.getAttribute('title') || '').trim();
    const text = ((el.textContent || '').trim() || '').slice(0, 80);

    // Always allow message rows
    if (tag === 'tr' && el.classList && el.classList.contains('zA')) return true;

    // Always allow native controls
    if (['button', 'a', 'input', 'select', 'textarea', 'form'].includes(tag)) return true;

    // Reject presentational
    if (role === 'presentation' || role === 'none') return false;

    // Require label/tooltip/title or meaningful text
    if (ariaLabel || tooltip || title) return true;
    if (role && text.length >= 2) return true;

    return false;
}

function extractFeatures(element, reason = '') {
    const rect = element.getBoundingClientRect();
    const style = window.getComputedStyle(element);

    const tagName = element.tagName ? element.tagName.toLowerCase() : '';
    const role = element.getAttribute('role') || '';
    const type = element.type || '';

    const ariaLabel = element.getAttribute('aria-label') || '';
    const tooltip = element.getAttribute('data-tooltip') || '';
    const title = element.getAttribute('title') || '';

    let text =
        (element.textContent || '').trim() ||
        element.value ||
        element.placeholder ||
        element.alt ||
        title ||
        ariaLabel ||
        tooltip ||
        '';

    // For message rows, extract subject/snippet
    if (tagName === 'tr' && element.classList && element.classList.contains('zA')) {
        const subject =
            (element.querySelector('.bog') && element.querySelector('.bog').textContent) ||
            (element.querySelector('[role="link"]') && element.querySelector('[role="link"]').textContent) ||
            '';
        const snippet =
            (element.querySelector('.y2') && element.querySelector('.y2').textContent) ||
            (element.querySelector('.xS') && element.querySelector('.xS').textContent) ||
            '';
        const composed = [subject.trim(), snippet.trim()].filter(Boolean).join(' — ');
        if (composed) text = composed;
    }

    text = (text || '').trim().substring(0, 220);

    return {
        reason,
        text,
        ariaLabel,
        tooltip,
        title,

        id: element.id || '',
        className: typeof element.className === 'string' ? element.className : (element.className || '').toString(),

        tagName,
        role,
        type,

        tabindex: element.getAttribute('tabindex'),

        x: rect.left,
        y: rect.top,
        width: rect.width,
        height: rect.height,
        centerX: rect.left + rect.width / 2,
        centerY: rect.top + rect.height / 2,

        cursor: style.cursor,
        zIndex: parseInt(style.zIndex) || 0,
        opacity: parseFloat(style.opacity) || 1,

        isButton: tagName === 'button' || role === 'button' || type === 'button' || type === 'submit',
        isLink: tagName === 'a' || role === 'link',
        isInput: tagName === 'input' || tagName === 'textarea' || tagName === 'select' || role === 'textbox',
        isRow: tagName === 'tr' || role === 'row',

        isFocusable: element.tabIndex >= 0,
    };
}