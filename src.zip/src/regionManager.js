// regionManager.js - Handles region-based navigation for Gmail

/**
 * Define Gmail regions with their selectors and metadata
 */
const GMAIL_REGIONS = [
    {
        id: 'header',
        name: 'Header',
        description: 'Search, settings, and account',
        selector: '[role="banner"]',
        icon: '🔍',
        priority: 1
    },
    // {
    //     id: 'compose-sidebar',
    //     name: 'Compose',
    //     description: 'Compose button',
    //     selector: 'div.aic',
    //     icon: '✍️',
    //     priority: 2
    // },
    {
        id: 'main',
        name: 'Email List',
        description: 'Your emails',
        selector: '[role="main"]',
        icon: '📬',
        priority: 3
    },
    {
        id: 'mail-navigation',
        name: 'Mail Navigation',
        description: 'Inbox, Starred, Sent, Drafts',
        selector: 'div.aBO',
        icon: '📧',
        priority: 4
    },
    {
        id: 'left-panel',
        name: 'Left Panel',
        description: 'Navigation panel',
        selector: '[role="navigation"]',
        icon: '📑',
        priority: 5
    },
    {
        id: 'right-panel',
        name: 'Right Panel',
        description: 'Calendar, Keep, Tasks, Contacts',
        selector: '[role="complementary"][aria-label*="Side panel"], [role="complementary"]',
        icon: '📅',
        priority: 6
    }
];

/**
 * Extract available regions from the current page
 */
export function extractRegions() {
    const regions = [];

    for (const regionDef of GMAIL_REGIONS) {
        const element = document.querySelector(regionDef.selector);

        if (element && isRegionVisible(element)) {
            // Count interactive elements in this region
            const interactiveCount = countInteractiveElements(element);

            regions.push({
                id: regionDef.id,
                name: regionDef.name,
                description: regionDef.description,
                icon: regionDef.icon,
                element: element,
                priority: regionDef.priority,
                interactiveCount: interactiveCount,
                bounds: element.getBoundingClientRect()
            });
        }
    }

    // Sort by priority
    regions.sort((a, b) => a.priority - b.priority);

    console.log(`🗺️ Found ${regions.length} regions:`, regions.map(r => `${r.icon} ${r.name} (${r.interactiveCount})`));
    return regions;
}

/**
 * Check if a region is visible and has reasonable size
 */
function isRegionVisible(element) {
    const rect = element.getBoundingClientRect();

    // Must have some size
    if (rect.width === 0 || rect.height === 0) {
        return false;
    }

    // Check computed style
    const style = window.getComputedStyle(element);
    if (style.display === 'none' ||
        style.visibility === 'hidden' ||
        style.opacity === '0') {
        return false;
    }

    return true;
}

/**
 * Count interactive elements within a region
 */
function countInteractiveElements(regionElement) {
    const interactiveSelectors = [
        'button',
        'a[href]',
        'input',
        'select',
        'textarea',
        '[role="button"]',
        '[role="link"]',
        '[role="menuitem"]',
        '[role="tab"]',
        '[onclick]'
    ];

    const selector = interactiveSelectors.join(', ');
    const elements = regionElement.querySelectorAll(selector);

    let count = 0;
    for (const el of elements) {
        if (isElementVisible(el)) {
            count++;
        }
    }

    return count;
}

/**
 * Check if element is visible
 */
function isElementVisible(element) {
    const rect = element.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) {
        return false;
    }

    const style = window.getComputedStyle(element);
    return style.display !== 'none' &&
        style.visibility !== 'hidden' &&
        parseFloat(style.opacity) > 0;
}

/**
 * Extract candidates within a specific region
 */
export function extractCandidatesInRegion(region, extractCandidatesFn) {
    if (!region || !region.element) {
        return [];
    }

    // CHANGED: Pass the region object to the extractor
    // The context-aware extractor will use region.id to determine what to extract
    const regionCandidates = extractCandidatesFn(region);

    console.log(`🎯 Found ${regionCandidates.length} candidates in "${region.name}" region`);
    return regionCandidates;
}

/**
 * Check if two rectangles overlap
 */
function isOverlapping(rect1, rect2) {
    return !(rect1.right < rect2.left ||
        rect1.left > rect2.right ||
        rect1.bottom < rect2.top ||
        rect1.top > rect2.bottom);
}

/**
 * Create visual overlay for region selection
 */
export function createRegionOverlay(regions, selectedIndex) {
    // Remove existing overlay
    removeRegionOverlay();

    if (regions.length === 0) {
        return null;
    }

    const overlay = document.createElement('div');
    overlay.id = 'tabtabgo-region-overlay';
    overlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 999998;
        pointer-events: none;
    `;

    // Highlight each region
    regions.forEach((region, index) => {
        const isSelected = index === selectedIndex;
        const bounds = region.bounds;

        // Create region highlight
        const highlight = document.createElement('div');
        highlight.className = 'region-highlight';
        highlight.style.cssText = `
            position: absolute;
            left: ${bounds.left}px;
            top: ${bounds.top}px;
            width: ${bounds.width}px;
            height: ${bounds.height}px;
            border: ${isSelected ? '4px' : '2px'} solid ${isSelected ? '#10b981' : '#93c5fd'};
            background: ${isSelected ? 'rgba(16, 185, 129, 0.1)' : 'rgba(147, 197, 253, 0.05)'};
            border-radius: 8px;
            pointer-events: none;
            transition: all 0.2s ease;
            box-shadow: ${isSelected ? '0 0 20px rgba(16, 185, 129, 0.4)' : '0 0 10px rgba(147, 197, 253, 0.2)'};
        `;

        // Create label
        // const label = document.createElement('div');
        // label.style.cssText = `
        //     position: absolute;
        //     top: ${isSelected ? '-8px' : '-6px'};
        //     left: 12px;
        //     background: ${isSelected ? '#10b981' : '#60a5fa'};
        //     color: white;
        //     padding: ${isSelected ? '8px 16px' : '6px 12px'};
        //     border-radius: 6px;
        //     font-size: ${isSelected ? '14px' : '12px'};
        //     font-weight: ${isSelected ? '600' : '500'};
        //     font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        //     box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
        //     white-space: nowrap;
        //     pointer-events: none;
        // `;
        // label.innerHTML = `${region.icon} ${region.name} <span style="opacity: 0.8; font-size: 0.9em;">(${region.interactiveCount} items)</span>`;
        //
        // highlight.appendChild(label);
        overlay.appendChild(highlight);
    });

    document.body.appendChild(overlay);
    return overlay;
}

/**
 * Remove region overlay
 */
export function removeRegionOverlay() {
    const existing = document.getElementById('tabtabgo-region-overlay');
    if (existing) {
        existing.remove();
    }
}

/**
 * Create region selection popup (alternative to overlay)
 */
export function createRegionSelectionPopup(regions, selectedIndex, mouseX, mouseY) {
    removeRegionSelectionPopup();

    if (regions.length === 0) {
        return null;
    }

    const popup = document.createElement('div');
    popup.id = 'tabtabgo-region-popup';
    popup.style.cssText = `
        position: fixed;
        left: ${mouseX}px;
        top: ${mouseY}px;
        background: white;
        border: 2px solid #10b981;
        border-radius: 12px;
        padding: 12px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
        z-index: 999999;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        min-width: 280px;
        max-width: 400px;
    `;

    // Header
    const header = document.createElement('div');
    header.style.cssText = `
        font-size: 13px;
        font-weight: 600;
        color: #10b981;
        margin-bottom: 8px;
        padding-bottom: 8px;
        border-bottom: 1px solid #e5e7eb;
    `;
    header.textContent = '📍 Select Region';
    popup.appendChild(header);

    // Region list
    const list = document.createElement('div');
    list.style.cssText = `
        display: flex;
        flex-direction: column;
        gap: 4px;
    `;

    regions.forEach((region, index) => {
        const isSelected = index === selectedIndex;

        const item = document.createElement('div');
        item.style.cssText = `
            padding: 10px 12px;
            background: ${isSelected ? '#10b981' : '#f9fafb'};
            color: ${isSelected ? 'white' : '#374151'};
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.2s ease;
            border: 2px solid ${isSelected ? '#10b981' : 'transparent'};
        `;

        item.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div style="display: flex; align-items: center; gap: 8px;">
                    <span style="font-size: 18px;">${region.icon}</span>
                    <div>
                        <div style="font-weight: 600; font-size: 14px; margin-bottom: 2px;">${region.name}</div>
                        <div style="font-size: 11px; opacity: 0.8;">${region.description}</div>
                    </div>
                </div>
                <div style="font-size: 12px; font-weight: 600; opacity: 0.8;">
                    ${region.interactiveCount}
                </div>
            </div>
        `;

        if (!isSelected) {
            item.addEventListener('mouseenter', () => {
                item.style.background = '#e5e7eb';
            });
            item.addEventListener('mouseleave', () => {
                item.style.background = '#f9fafb';
            });
        }

        list.appendChild(item);
    });

    popup.appendChild(list);

    // Instructions
    const instructions = document.createElement('div');
    instructions.style.cssText = `
        margin-top: 12px;
        padding-top: 12px;
        border-top: 1px solid #e5e7eb;
        font-size: 11px;
        color: #6b7280;
        line-height: 1.5;
    `;
    instructions.innerHTML = `
        <div style="margin-bottom: 4px;"><kbd style="background: #f3f4f6; padding: 2px 6px; border-radius: 3px; font-family: monospace;">Tab</kbd> or <kbd style="background: #f3f4f6; padding: 2px 6px; border-radius: 3px; font-family: monospace;">D</kbd> Next region</div>
        <div style="margin-bottom: 4px;"><kbd style="background: #f3f4f6; padding: 2px 6px; border-radius: 3px; font-family: monospace;">Shift+Tab</kbd> or <kbd style="background: #f3f4f6; padding: 2px 6px; border-radius: 3px; font-family: monospace;">S</kbd> Previous region</div>
        <div><kbd style="background: #f3f4f6; padding: 2px 6px; border-radius: 3px; font-family: monospace;">Enter</kbd> or <kbd style="background: #f3f4f6; padding: 2px 6px; border-radius: 3px; font-family: monospace;">W</kbd> Select region</div>
    `;
    popup.appendChild(instructions);

    document.body.appendChild(popup);

    // Position adjustment if popup goes off-screen
    const rect = popup.getBoundingClientRect();
    if (rect.right > window.innerWidth) {
        popup.style.left = `${window.innerWidth - rect.width - 20}px`;
    }
    if (rect.bottom > window.innerHeight) {
        popup.style.top = `${window.innerHeight - rect.height - 20}px`;
    }

    return popup;
}

/**
 * Remove region selection popup
 */
export function removeRegionSelectionPopup() {
    const existing = document.getElementById('tabtabgo-region-popup');
    if (existing) {
        existing.remove();
    }
}